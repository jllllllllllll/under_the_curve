#!/bin/bash
cd /root/LLaMA-Factory/chuli/多轮脚本
python 优化格式.py
python 成品输出.py