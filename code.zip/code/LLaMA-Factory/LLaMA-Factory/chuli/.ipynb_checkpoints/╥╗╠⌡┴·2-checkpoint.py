import subprocess



subprocess.run(["python", "/root/LLaMA-Factory/chuli/第二点五步格式调整2.py"])

subprocess.run(["python", "/root/LLaMA-Factory/chuli/第三步转换格式2.py"])