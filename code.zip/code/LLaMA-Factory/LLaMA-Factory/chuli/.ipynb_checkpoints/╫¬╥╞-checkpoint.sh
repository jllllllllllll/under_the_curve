#!/bin/bash


mv /root/Qwen2-7B-Chat /root/autodl-tmp