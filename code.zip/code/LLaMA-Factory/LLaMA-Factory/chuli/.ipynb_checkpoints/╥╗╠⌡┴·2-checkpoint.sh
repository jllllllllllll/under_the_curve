#!/bin/bash

cd /root/LLaMA-Factory/chuli

python 一条龙2.py