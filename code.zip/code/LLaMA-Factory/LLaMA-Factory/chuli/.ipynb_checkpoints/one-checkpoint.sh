#!/bin/bash

source activate llama
cd /root/LLaMA-Factory/src

python webui.py