import subprocess


subprocess.run(["python", "/root/LLaMA-Factory/chuli/第一步处理文本.py"])

subprocess.run(["python", "/root/LLaMA-Factory/chuli/第二步模型.py"])

subprocess.run(["python", "/root/LLaMA-Factory/chuli/第二点五步格式调整.py"])

subprocess.run(["python", "/root/LLaMA-Factory/chuli/第三步转换格式.py"])