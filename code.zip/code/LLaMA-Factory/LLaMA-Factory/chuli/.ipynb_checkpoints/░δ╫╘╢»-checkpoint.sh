#!/bin/bash

cd /root/LLaMA-Factory/chuli

python 一条龙.py