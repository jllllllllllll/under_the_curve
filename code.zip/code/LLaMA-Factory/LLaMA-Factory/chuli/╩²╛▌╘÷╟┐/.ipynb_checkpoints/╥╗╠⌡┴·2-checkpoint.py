import subprocess



subprocess.run(["python", "/root/LLaMA-Factory/chuli/数据增强/第二点五步格式调整2.py"])

subprocess.run(["python", "/root/LLaMA-Factory/chuli/数据增强/第三步转换格式2.py"])

subprocess.run(["python", "/root/LLaMA-Factory/chuli/数据增强/数据重述.py"])

subprocess.run(["python", "/root/LLaMA-Factory/chuli/数据增强/数据集合二为一.py"])