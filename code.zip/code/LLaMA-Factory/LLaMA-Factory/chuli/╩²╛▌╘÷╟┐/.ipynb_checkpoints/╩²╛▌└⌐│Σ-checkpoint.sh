#!/bin/bash

cd /root/LLaMA-Factory/chuli/数据增强

python 一条龙2.py