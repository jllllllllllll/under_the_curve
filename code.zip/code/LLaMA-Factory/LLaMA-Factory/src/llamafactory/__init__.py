# Level: api, webui > chat, eval, train > data, model > hparams > extras

from .cli import VERSION


__version__ = VERSION
