from llamafactory.train.tuner import run_exp


def launch():
    run_exp()


if __name__ == "__main__":
    launch()
